import psycopg2
from psycopg2.extras import RealDictCursor
import os
from dotenv import load_dotenv

load_dotenv()

def get_connection():
    return psycopg2.connect(
        os.getenv("SUPABASE_DB_URL"),
        cursor_factory=RealDictCursor
    )

if __name__ == "__main__":
    try:
        conn = get_connection()
        cur = conn.cursor()

        # simple test query
        cur.execute("SELECT 1;")
        result = cur.fetchone()

        print("✅ Database connection successful!")
        print("Test query result:", result)

        cur.close()
        conn.close()

    except Exception as e:
        print("❌ Database connection failed")
        print("Error:", e)
